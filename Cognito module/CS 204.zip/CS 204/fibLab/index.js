'use strict';
console.log('Loading fibonacci function');
 
exports.handler = async (event) => {
    let n = -1;
    let responseCode = 200;
    console.log("request: " + JSON.stringify(event));
    
    if (event.queryStringParameters && event.queryStringParameters.n) {
        console.log("Received n integer: " + event.queryStringParameters.n);
        n = event.queryStringParameters.n;
    }
    else if (event && event.n) {
        console.log("Received n integer: " + event.n);
        n = event.n;
    }
 
    let fibVal = fibonacci(n);
    let author = `Drew Bayles`;

    let responseBody = {
        fibonacci: fibVal,
        author: author
    };
    
    // The output from a Lambda proxy integration must be 
    // in the following JSON object. The 'headers' property 
    // is for custom response headers in addition to standard 
    // ones. The 'body' property  must be a JSON string. For 
    // base64-encoded payload, you must also set the 'isBase64Encoded'
    // property to 'true'.
    let response = {
        statusCode: responseCode,
        headers: {
            "x-custom-header" : "my custom header value"
        },
        body: JSON.stringify(responseBody)
    };
    console.log("response: " + JSON.stringify(response))
    return response;
    
    function fibonacci(num) {
        var num1=0;
        var num2=1;
        var sum;
        var i=0;
        for (i = 0; i < num; i++) 
        {
            sum=num1+num2;
            num1=num2;
            num2=sum;
        }
        if (num1 == 0)
            return 1;
        else
            return num1;
    }
  
};
